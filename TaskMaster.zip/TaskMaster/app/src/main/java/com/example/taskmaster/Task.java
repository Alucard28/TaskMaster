package com.example.taskmaster;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class Task extends AppCompatActivity {

    private EditText editTextInput;
    private Button buttonIngresar;
    private TableLayout table;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task);

        editTextInput = findViewById(R.id.editText);
        buttonIngresar = findViewById(R.id.ingresar);
        table = findViewById(R.id.tableLayout);

        buttonIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputText = editTextInput.getText().toString();
                if (!inputText.isEmpty()) {
                    addTextToTable(inputText);
                    editTextInput.setText(""); // Limpiar el campo de texto
                }
            }
        });
    }//prueba
    private void addTextToTable(String text) {
        TableRow tableRow = new TableRow(this);
        TextView textView = new TextView(this);
        textView.setText(text);
        textView.setPadding(16, 16, 16, 16);
        tableRow.addView(textView);
        table.addView(tableRow);
    }
}