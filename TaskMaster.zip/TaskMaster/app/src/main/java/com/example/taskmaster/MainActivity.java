package com.example.taskmaster;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private TextView textView;
    private int progressStatus = 0;
    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progressBar);

        // Iniciar el hilo para actualizar el progreso
        new Thread(new Runnable() {
            public void run() {
                while (progressStatus < 100) {
                    progressStatus += 1;

                    // Actualizar el progreso en el ProgressBar
                    handler.post(new Runnable() {
                        public void run() {
                            progressBar.setProgress(progressStatus);
                        }
                    });

                    try {
                        // Simular un tiempo de carga
                        Thread.sleep(100); // 100 ms
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                // Cambiar a la nueva actividad cuando el progreso esté completo
                Intent intent = new Intent(MainActivity.this, Task.class);
                startActivity(intent);
                finish(); // Cerrar la actividad actual
            }
        }).start();
    }
}